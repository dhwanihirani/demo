class Symptoms {
  String? name;
  String? severity;
  String? dateTime;
  String? note;

  Symptoms.fromJson(dynamic json) {
    name = json['name'];
    severity = json['severity'];
    dateTime = json['dateTime'];
    note = json['note'];
  }

  Map<String, dynamic> toJson() {
    Map<String, dynamic> map = {};
    map['name'] = name;
    map['severity'] = severity;
    map['dateTime'] = dateTime;
    map['note'] = note;
    return map;
  }
}