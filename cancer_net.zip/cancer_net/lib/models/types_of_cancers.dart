class TypesOfCancers {
  String? name;
  bool? isChecked;

  TypesOfCancers.fromJson(dynamic json) {
    name = json['name'];
    isChecked = json['isChecked'];
  }

  Map<String, dynamic> toJson() {
    Map<String, dynamic> map = {};
    map['name'] = name;
    map['isChecked'] = isChecked;
    return map;
  }
}