import 'package:flutter/material.dart';
import '../../core/constColor.dart';
import '../../core/constFonts.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'dart:io' show Platform;

class CancerWebViewPage extends StatefulWidget {
  final String? name;
  final String? url;
  final String? pageName;
  const CancerWebViewPage({Key? key,this.name,this.url,this.pageName}) : super(key: key);

  @override
  State<CancerWebViewPage> createState() => _CancerWebViewPageState();
}

class _CancerWebViewPageState extends State<CancerWebViewPage> {

  bool isBookmark = true;

  @override
  void initState() {
    if (Platform.isAndroid) WebView.platform = AndroidWebView();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
      child: Scaffold(
        appBar:  AppBar(
          backgroundColor: ConstColour.appBarColor,
          title: Text('${widget.name}',
            style: const TextStyle(
              color: ConstColour.appBarFontColor,
              fontFamily: ConstFont.primaryFontFamily,
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),
          ),
          actions: [
            IconButton(
                onPressed: (){
                  setState(() {
                    isBookmark = !isBookmark;
                  });
                },
                icon: Icon(isBookmark == true ? Icons.bookmark : Icons.bookmark_border_outlined)),
          ],
        ),
        body: WebView(
          initialUrl: '${widget.url}',
          javascriptMode: JavascriptMode.unrestricted,
        )
      ),
    );
  }
}
