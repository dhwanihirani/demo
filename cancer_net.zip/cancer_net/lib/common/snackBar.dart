import 'package:flutter/material.dart';
import '../core/constFonts.dart';

void showSnackBar({required BuildContext context, String? text}) {
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(
      content: MediaQuery(
        data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
        child: Text(
          text!,
          style: const TextStyle(
            fontFamily: ConstFont.primaryFontFamily,
          ),
        ),
      ),
    ),
  );
}