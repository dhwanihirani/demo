import 'package:cancer_net/core/constFonts.dart';
import 'package:cancer_net/home_page.dart';
import 'package:cancer_net/information.dart';
import 'package:flutter/material.dart';

import '../core/constColor.dart';
import '../src/About/aboutPage.dart';
import '../src/Bookmarks/bookmarksPage.dart';

class BottomTabBarView extends StatefulWidget {
  int? currentTab;
  BottomTabBarView({Key? key,this.currentTab}) : super(key: key);

  @override
  State<BottomTabBarView> createState() => _BottomTabBarViewState();
}

class _BottomTabBarViewState extends State<BottomTabBarView> {

  int selectedTab = 0;
  Widget currentPage = const AboutPage();
  void selectTab(int item) {
    widget.currentTab = item;
    selectedTab = item;
    switch (item) {
      case 0:
        currentPage = const HomePage();
        break;

      case 1:
        currentPage = const Information();
        break;

      case 2:
        currentPage = const BookmarksPage();
        break;

      case 3:
        currentPage = const AboutPage();
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return MediaQuery(
      data:  MediaQuery.of(context).copyWith(textScaleFactor: 1),
      child: Scaffold(
        body: currentPage,
        bottomNavigationBar: BottomNavigationBar(
          iconSize: 25,
          backgroundColor: const Color(0xFFFAFAFA),
          type: BottomNavigationBarType.fixed,
          selectedLabelStyle: const TextStyle(
            color: ConstColour.primaryFontColor,
            fontSize: 14,
            fontWeight: FontWeight.normal,
            fontFamily: ConstFont.primaryFontFamily,
          ),
          selectedItemColor: ConstColour.primaryFontColor,
          unselectedLabelStyle: const TextStyle(
            color: Color(0xFFA5A5A5),
            fontSize: 13,
            fontWeight: FontWeight.normal,
            fontFamily: ConstFont.primaryFontFamily,
          ),
           //unselectedItemColor: Colors.black,//const Color(0xFF737373),
          onTap: (index){
            setState(() {
              selectTab(index);
            });
          },
          currentIndex: selectedTab,
          items: [
        BottomNavigationBarItem(
          icon: Icon(
              selectedTab == 0 ? Icons.monitor_heart : Icons.monitor_heart_outlined,
              color: selectedTab == 0 ? ConstColour.bgIconColor : Colors.black),
          label: 'My Health',
        ),
            BottomNavigationBarItem(
              icon: Icon(
                  selectedTab == 1 ?Icons.menu_book : Icons.menu_book_outlined,
                  color: selectedTab == 1 ? ConstColour.bgIconColor : Colors.black),
              label: 'Information',
            ),
            BottomNavigationBarItem(
              icon: Icon(
                  selectedTab == 2 ?Icons.bookmark : Icons.bookmark_border_outlined,
                  color: selectedTab == 2 ? ConstColour.bgIconColor : Colors.black),
              label: 'Bookmarks',
            ),
            BottomNavigationBarItem(
              icon: Icon(
                  selectedTab == 3 ? Icons.info : Icons.info_outline,
                  color: selectedTab == 3 ?ConstColour.bgIconColor : Colors.black),
              label: 'About',
            ),
          ])
      ),
    );
  }
}
