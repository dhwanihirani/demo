import 'package:flutter/material.dart';

import '../core/constColor.dart';
import '../core/constFonts.dart';

class CheckBoxModel{
  int? id;
  String? title;
  bool? isCheck;

  CheckBoxModel({this.id,this.title,this.isCheck});
}

Widget buildCheckBoxList({ValueChanged<bool?>?  onChange, bool? value, String? title}){
  return CheckboxListTile(
    contentPadding: const EdgeInsets.all(0),
    controlAffinity: ListTileControlAffinity.leading,
    dense: true,
    checkColor: ConstColour.white,
    activeColor: ConstColour.bgIconColor,
    value: value,
    checkboxShape: const RoundedRectangleBorder(side: BorderSide(width: 2,color: Colors.black26)),
    onChanged: onChange,
    title: Text(
      '$title',
      style: const TextStyle(
        fontWeight: FontWeight.w400,
        fontFamily: ConstFont.primaryFontFamily,
        fontSize: 15.0,
        color: Colors.black,
      ),
      textAlign: TextAlign.start,
    ),
  );
}
