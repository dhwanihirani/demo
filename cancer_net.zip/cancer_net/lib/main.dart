import 'package:cancer_net/core/constRoute.dart';
import 'package:cancer_net/core/routePage.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'firebase_option.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    name: "CancerNet",
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  String get name => 'foo';

  Future<void> initializeDefault() async {
    FirebaseApp app = await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
    debugPrint('Initialized default app $app');
  }

  Future<void> initializeDefaultFromAndroidResource() async {
    if (defaultTargetPlatform != TargetPlatform.android || kIsWeb) {
      debugPrint('Not running on Android, skipping');
      return;
    }
    FirebaseApp app = await Firebase.initializeApp();
    debugPrint('Initialized default app $app from Android resource');
  }

  Future<void> initializeSecondary() async {
    FirebaseApp app = await Firebase.initializeApp(
      name: name,
      options: DefaultFirebaseOptions.currentPlatform,
    );

    debugPrint('Initialized $app');
  }

  void apps() {
    final List<FirebaseApp> apps = Firebase.apps;
    debugPrint('Currently initialized apps: $apps');
  }

  void options() {
    final FirebaseApp app = Firebase.app();
    final options = app.options;
    debugPrint('Current options for app ${app.name}: $options');
  }

  Future<void> delete() async {
    final FirebaseApp app = Firebase.app(name);
    await app.delete();
    debugPrint('App $name deleted');
  }

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'Cancer Net',
      debugShowCheckedModeBanner: false,
      initialRoute: ConstRoute.welcomePage,
      onGenerateRoute: RoutePage.generateRoute,
    );
  }
}
