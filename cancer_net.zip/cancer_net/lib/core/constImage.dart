class ConstImg{
  static const String welcome1 = 'assets/welcome1.jpg';
  static const String welcome2 = 'assets/welcome2.jpg';
  static const String welcome3 = 'assets/welcome3.jpg';
  static const String welcome4 = 'assets/welcome4.jpg';
  static const String welcome5 = 'assets/welcome5.jpg';
  static const String welcome8 = 'assets/welcome8.jpg';
  static const String welcome9 = 'assets/welcome9.jpg';
  static const String welcome10 = 'assets/welcome10.jpg';
}