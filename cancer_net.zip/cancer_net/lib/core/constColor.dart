import 'package:flutter/cupertino.dart';

class ConstColour {
  static const Color primaryColor = Color(0xFF0A2455);
  static const Color bgColor = Color(0xFFDBE7F3);
  static const Color white = Color(0xFFFFFEFE);
  static const Color primaryFontColor = Color(0xFF283E68);
  static const Color secondFontColor = Color(0xFF2C2D2C);
  static const Color bgIconColor = Color(0xFFEEC042);
  static const Color tabBarColor = Color(0xFF385F8D);
  static const Color appBarColor = Color(0xFF132251);
  static const Color appBarFontColor = Color(0xFFEFEFF1);
}