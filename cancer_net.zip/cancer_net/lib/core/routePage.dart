import 'package:cancer_net/src/symptoms/add_symptoms_screen.dart';
import 'package:cancer_net/src/symptoms/symptoms_screen.dart';
import 'package:cancer_net/types_of_cancer.dart';
import 'package:flutter/material.dart';
import '../common/bottomTabBarViewPage.dart';
import '../common/cancerWebView.dart';
import '../src/About/aboutPage.dart';
import '../src/About/aboutUsPage.dart';
import '../src/About/appRatePage.dart';
import '../src/About/contactUsPage.dart';
import '../src/About/helpWithThisAppPage.dart';
import '../src/About/privacyAndPolicyPage.dart';
import '../src/WelcomeScreen/welcomePage.dart';
import '../src/About/welcomeTourPage.dart';
import '../src/WelcomeScreen/welcome_fourPage.dart';
import '../src/WelcomeScreen/welcome_secondPage.dart';
import '../src/WelcomeScreen/welcome_thirdPage.dart';
import 'constRoute.dart';

class RoutePage {
  static Route<dynamic>? generateRoute(RouteSettings? settings) {
    List? args = settings!.arguments as List?;
    switch (settings.name) {
      case ConstRoute.welcomePage:
        return MaterialPageRoute(builder: (_) => const WelcomePage());
        case ConstRoute.welcomeSecondPage:
        return MaterialPageRoute(builder: (_) => const WelcomeSecondPage());
        case ConstRoute.welcomeThirdPage:
        return MaterialPageRoute(builder: (_) => WelcomeThirdPage(id: args![0],));
        case ConstRoute.welcomeFourPage:
        return MaterialPageRoute(builder: (_) => const WelcomeFourPage());
        case ConstRoute.welcomeTourPage:
        return MaterialPageRoute(builder: (_) => const WelcomeTour());
        case ConstRoute.bottomTabBarView:
        return MaterialPageRoute(builder: (_) => BottomTabBarView(currentTab: args![0],));
        case ConstRoute.aboutPage:
        return MaterialPageRoute(builder: (_) => const AboutPage());
        case ConstRoute.aboutUsPage:
        return MaterialPageRoute(builder: (_) => const AboutUsPage());
        case ConstRoute.contactUsPage:
        return MaterialPageRoute(builder: (_) => const ContactUsPage());
        case ConstRoute.privacyAndPolicyPage:
        return MaterialPageRoute(builder: (_) => const PrivacyAndPolicyPage());
        case ConstRoute.helpWithThisAppPage:
        return MaterialPageRoute(builder: (_) => const HelpWithThisAppPage());
        case ConstRoute.appRatePage:
        return MaterialPageRoute(builder: (_) => const AppRatePage());
        case ConstRoute.cancerWebViewPage:
        return MaterialPageRoute(builder: (_) => CancerWebViewPage(pageName: args![0], name: args[1], url: args[2]));
        case ConstRoute.typesOfCancer:
        return MaterialPageRoute(builder: (_) => const TypesOfCancer());
        case ConstRoute.symptoms:
        return MaterialPageRoute(builder: (_) => const SymptomsScreen());
        case ConstRoute.addSymptoms:
        return MaterialPageRoute(builder: (_) => const AddSymptomsScreen());
    }
    return null;
  }
}