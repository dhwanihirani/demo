class ConstFont {
  static const String primaryFontFamily = 'Poppins';
}