class ConstRoute {
  static const String welcomePage = 'welcomePage';
  static const String welcomeSecondPage = 'welcome_secondPage';
  static const String welcomeThirdPage = 'welcome_thirdPage';
  static const String welcomeFourPage = 'welcome_fourPage';
  static const String welcomeTourPage = 'welcomeTourPage';
  static const String bottomTabBarView = 'bottomTabBarView';
  static const String aboutPage = 'aboutPage';
  static const String aboutUsPage = 'aboutUsPage';
  static const String contactUsPage = 'contactUsPage';
  static const String privacyAndPolicyPage = 'privacyAndPolicyPag';
  static const String helpWithThisAppPage = 'helpWithThisAppPage';
  static const String appRatePage = 'appRatePage';
  static const String cancerWebViewPage = 'cancerWebViewPage';
  static const String typesOfCancer = 'typesOfCancer';
  static const String symptoms = 'symptoms';
  static const String addSymptoms = 'addSymptoms';
}