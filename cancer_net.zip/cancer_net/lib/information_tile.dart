import 'package:flutter/material.dart';

class InformationTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final bool isSubtitle;
  final GestureTapCallback onTap;
  const InformationTile({Key? key, required this.title, required this.subtitle, required this.isSubtitle, required this.onTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      child: ListTile(
        onTap: onTap,
        visualDensity: VisualDensity(vertical: -2),
        contentPadding: EdgeInsets.symmetric(horizontal: 12),
        title: Text(
          title,
          style: TextStyle(
              fontSize: 16,
              color: Color(0xFF02243B),
              fontWeight: FontWeight.w400
          ),
        ),
        subtitle: isSubtitle ? Text(
          subtitle,
          style: TextStyle(
              fontSize: 12,
              color: Colors.grey.shade500
          ),
        ) : null,
        trailing: Container(
          height: 25,
          width: 25,
          alignment: Alignment.center,
          decoration: BoxDecoration(
              color: Colors.amberAccent,
              shape: BoxShape.circle
          ),
          child: Icon(
            Icons.arrow_forward_ios_outlined,
            color: Colors.black,
            size: 20,
          ),
        ),
      ),
    );
  }
}
