import 'package:cancer_net/core/constRoute.dart';
import 'package:cancer_net/information_tile.dart';
import 'package:flutter/material.dart';

class Information extends StatefulWidget {
  const Information({super.key});

  @override
  State<Information> createState() => _InformationState();
}

class _InformationState extends State<Information> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: const Color(0xFFC7F1FF),
        appBar: AppBar(
          backgroundColor: const Color(0xFF02243B),
          title: const Text(
            "Information",
            style: TextStyle(
                fontSize: 18,
                color: Colors.white,
                fontWeight: FontWeight.w400
            ),
          ),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(4),
          child: Column(
            children: [
              InformationTile(title: "Types of Cancer", subtitle: "", isSubtitle: false, onTap: () {
                Navigator.of(context).pushNamed(ConstRoute.typesOfCancer);
              },),
              InformationTile(title: "Cancer Basics", subtitle: "An introduced to cancer, the health care team, and how cancer is diagnosed", isSubtitle: true, onTap: () {},),
              InformationTile(title: "Managing Your Care and Treatment", subtitle: "Take an active role in your cancer care and manage the different aspects of treatment", isSubtitle: true, onTap: () {},),
              InformationTile(title: "Common Concerns", subtitle: "How to navigate cancer at various ages and manage other concerns", isSubtitle: true, onTap: () {},),
              InformationTile(title: "Physical, Emotional, and Social Effects of Cancer", subtitle: "Ways to improve quality of life and manage the physical and emotional effect of cancer", isSubtitle: true, onTap: () {},),
              InformationTile(title: "Survivorship", subtitle: "Living with cancer and leading a healthy lifestyle during and after treatment", isSubtitle: true, onTap: () {},),
              InformationTile(title: "Finding Support and Information", subtitle: "Find resources and support to fit your needs", isSubtitle: true, onTap: () {},),
              InformationTile(title: "Caring for a Loved One", subtitle: "Tips on caregiving and supporting your loved ones with cancer", isSubtitle: true, onTap: () {},),
            ],
          ),
        )
    );
  }


}