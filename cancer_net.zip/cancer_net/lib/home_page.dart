import 'package:cancer_net/core/constColor.dart';
import 'package:cancer_net/core/constFonts.dart';
import 'package:cancer_net/core/constImage.dart';
import 'package:cancer_net/core/constRoute.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ConstColour.bgColor,
      appBar: _buildAppBar(),
      body: _buildBody(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: ConstColour.appBarColor,
      elevation: 0,
      title: const Text(
        "My Health",
        style: TextStyle(
          color: ConstColour.appBarFontColor,
          fontFamily: ConstFont.primaryFontFamily,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildBody() {
    return SingleChildScrollView(
      child: Column(
        children: [
          _buildTopUi(),
          const SizedBox(height: 12,),
          _buildMenus(),
        ],
      ),
    );
  }

  Widget _buildTopUi() {
    return Stack(
      alignment: Alignment.bottomCenter,
      children: [
        Container(
          height: 100,
          margin: const EdgeInsets.only(bottom: 20),
          decoration: const BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  ConstColour.appBarColor,
                  ConstColour.primaryFontColor,
                  ConstColour.tabBarColor,
                ]
            ),
          ),
        ),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(4)
                  ),
                  child: Column(
                    children: const [
                      Icon(
                        Icons.monitor_heart,
                        color: Colors.black,
                      ),
                      Text(
                        "Add a Symptom",
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w400,
                          color: Colors.black
                        ),
                      )
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 12,),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(4)
                  ),
                  child: Column(
                    children: const [
                      Icon(
                        Icons.note_alt_outlined,
                        color: Colors.black,
                      ),
                      Text(
                        "Ask a Question",
                        style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w400,
                            color: Colors.black
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildMenus() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          _buildMenuTile(
              image: ConstImg.welcome1,
              title: "Symptoms",
              subtitle: "Log your symptoms and rate their severity",
              onTap: () {
                Navigator.of(context).pushNamed(ConstRoute.symptoms);
              },
          ),
          const SizedBox(height: 12,),
          _buildMenuTile(
              image: ConstImg.welcome2,
              title: "Questions",
              subtitle: "Track questions to ask your health care team and record their answers",
              onTap: () {},
          ),
          const SizedBox(height: 12,),
          _buildMenuTile(
              image: ConstImg.welcome3,
              title: "Medications",
              subtitle: "List medications and set reminder notifications",
              onTap: () {},
          ),
          const SizedBox(height: 12,),
          _buildMenuTile(
              image: ConstImg.welcome4,
              title: "Providers",
              subtitle: "Add your health care providers and their contact information",
              onTap: () {},
          ),
          const SizedBox(height: 12,),
          _buildMenuTile(
              image: ConstImg.welcome5,
              title: "Appointments",
              subtitle: "Enter appointments and sync with your calender or share with others",
              onTap: () {},
          ),
          const SizedBox(height: 12,),
          _buildMenuTile(
              image: ConstImg.welcome8,
              title: "My Health Report",
              subtitle: "View, email, or print a report of information tracked within this app",
              onTap: () {},
          ),
        ],
      ),
    );
  }

  Widget _buildMenuTile({
    required String image,
    required String title,
    required String subtitle,
    required void Function()? onTap
  }) {
    return Card(
      color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
      elevation: 0,
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.all(12),
        visualDensity: const VisualDensity(vertical: -2, horizontal: -2),
        leading: Image.asset(
          image,
          height: 100,
          width: 100,
          fit: BoxFit.cover,
        ),
        title: Text(
          title,
          style: const TextStyle(
              fontSize: 18,
              color: ConstColour.primaryFontColor,
              fontWeight: FontWeight.w400
          ),
        ),
        subtitle: Text(
          subtitle,
          style: const TextStyle(
              fontSize: 12,
              color: ConstColour.secondFontColor,
              fontWeight: FontWeight.w300
          ),
        ),
        trailing: Container(
          height: 20,
          width: 20,
          alignment: Alignment.center,
          decoration: const BoxDecoration(
            shape: BoxShape.circle,
            color: ConstColour.bgIconColor,
          ),
          child: const Icon(
            Icons.arrow_forward_ios,
            size: 12,
            color: ConstColour.primaryColor,
          ),
        ),
      ),
    );
  }
}
