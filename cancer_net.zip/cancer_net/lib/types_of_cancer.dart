import 'package:flutter/material.dart';

class TypesOfCancer extends StatefulWidget {
  const TypesOfCancer({Key? key}) : super(key: key);

  @override
  State<TypesOfCancer> createState() => _TypesOfCancerState();
}

class _TypesOfCancerState extends State<TypesOfCancer> {

  List<TypesOfCancerData> listTypesOfCancerData = [
    TypesOfCancerData(title: "Adenoid Cystic Carcinoma", isSelect: false),
    TypesOfCancerData(title: "Adrenal Gland Tumor", isSelect: false),
    TypesOfCancerData(title: "Amyloidosis", isSelect: false),
    TypesOfCancerData(title: "Anal Cancer", isSelect: false),
    TypesOfCancerData(title: "Appendix Cancer", isSelect: false),
    TypesOfCancerData(title: "Astrocytoma - Childhood", isSelect: false),
    TypesOfCancerData(title: "Bile Duct Cancer", isSelect: false),
    TypesOfCancerData(title: "Bladder Cancer", isSelect: false),
    TypesOfCancerData(title: "Bone Cancer (Sarcoma of Bone)", isSelect: false),
    TypesOfCancerData(title: "Brain Stem Glioma - Childhood", isSelect: false),
    TypesOfCancerData(title: "Brain Tumor", isSelect: false),
    TypesOfCancerData(title: "Breast Cancer", isSelect: false),
    TypesOfCancerData(title: "Breast Cancer - Inflammatory", isSelect: false),
    TypesOfCancerData(title: "Breast Cancer - Metastatic", isSelect: false),
    TypesOfCancerData(title: "Breast Cancer, Male", isSelect: false),
    TypesOfCancerData(title: "Central Nervous System Tumors", isSelect: false),
    TypesOfCancerData(title: "Cervical Cancer", isSelect: false),
    TypesOfCancerData(title: "Childhood Cancer", isSelect: false),
    TypesOfCancerData(title: "Colorectal Cancer", isSelect: false),
    TypesOfCancerData(title: "Craniopharyngioma - Childhood", isSelect: false),
    TypesOfCancerData(title: "Desmoid Tumor", isSelect: false),
    TypesOfCancerData(title: "Desmoplastic Infantile", isSelect: false),
    TypesOfCancerData(title: "Ependymoma - Childhood", isSelect: false),
    TypesOfCancerData(title: "Esophageal Cancer", isSelect: false),
    TypesOfCancerData(title: "Ewing Sarcoma - Childhood", isSelect: false),
    TypesOfCancerData(title: "Eye Melanoma", isSelect: false),
    TypesOfCancerData(title: "Eyelid Cancer", isSelect: false),
    TypesOfCancerData(title: "Gallbladder Cancer", isSelect: false),
    TypesOfCancerData(title: "Gastrointestinal Stromal Tumor - GIST", isSelect: false),
    TypesOfCancerData(title: "Germ Cell Tumor - Childhood", isSelect: false),
    TypesOfCancerData(title: "Gestational Trophoblastic Disease", isSelect: false),
    TypesOfCancerData(title: "Head and Neck Cancer", isSelect: false),
    TypesOfCancerData(title: "HIV/AIDS - Related Cancer", isSelect: false),
    TypesOfCancerData(title: "Kidney Cancer", isSelect: false),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFC7F1FF),
      appBar: _buildAppBar(),
      body: _buildBody(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: const Color(0xFF02243B),
      leading: IconButton(
        onPressed: () {
          Navigator.of(context).pop();
        },
        icon: const Icon(
          Icons.arrow_back_ios_new_outlined,
          color: Colors.white,
        ),
      ),
      title: const Text(
        "Choose Cancer Types",
        style: TextStyle(
            fontSize: 18,
            color: Colors.white,
            fontWeight: FontWeight.w400
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {},
          style: TextButton.styleFrom(
            padding: EdgeInsets.zero
          ),
          child: const Text(
            "Save",
            style: TextStyle(
              fontSize: 16,
              color: Colors.white
            ),
          ),
        )
      ],
    );
  }

  Widget _buildBody() {
    return ListView.separated(
      itemCount: listTypesOfCancerData.length,
      itemBuilder: (context, index) {
        return _buildCheckBoxTile(
          title: listTypesOfCancerData[index].title ?? "",
          isSelect: listTypesOfCancerData[index].isSelect ?? false,
          onChanged: (value) {
            listTypesOfCancerData[index].isSelect = value!;
            if (mounted) setState(() {});
          },
        );
      },
      separatorBuilder: (context, index) {
        return const Divider(
          height: 1,
          thickness: 1,
          color: Colors.grey,
        );
      },
    );
  }

  Widget _buildCheckBoxTile({required String title, required bool isSelect, required void Function(bool?)? onChanged}) {
    return Container(
      color: Colors.white,
      child: CheckboxListTile(
        value: isSelect,
        onChanged: onChanged,
        controlAffinity: ListTileControlAffinity.leading,
        title: Text(
          title,
          style: const TextStyle(
              fontSize: 18,
              color: Color(0xFF02243B),
              fontWeight: FontWeight.w300
          ),
        ),
      ),
    );
  }
}

class TypesOfCancerData {
  String? title;
  bool? isSelect;

  TypesOfCancerData({this.title, this.isSelect});
}