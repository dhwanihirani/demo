import 'package:cancer_net/models/symptoms.dart';
import 'package:cancer_net/models/types_of_cancers.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseDatabaseService {
  FirebaseFirestore firestore = FirebaseFirestore.instance;


  Future addSymptoms(Symptoms symptoms) async {
    CollectionReference addSymptoms = firestore.collection("symptoms");
    await addSymptoms.add(symptoms.toJson());
  }

  Future getTypesOfCancers(TypesOfCancers typesOfCancer) async {
    CollectionReference typesOfCancers = firestore.collection("typesOfCancers");
    await typesOfCancers.add(typesOfCancer.toJson());
  }
}