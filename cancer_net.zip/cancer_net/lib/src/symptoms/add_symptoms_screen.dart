import 'package:flutter/material.dart';

class AddSymptomsScreen extends StatefulWidget {
  const AddSymptomsScreen({Key? key}) : super(key: key);

  @override
  State<AddSymptomsScreen> createState() => _AddSymptomsScreenState();
}

class _AddSymptomsScreenState extends State<AddSymptomsScreen> {

  Severity selectedSeverity = Severity.mild;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(),
      body: _buildBody(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      leading: IconButton(
        onPressed: () {
          Navigator.of(context).pop();
        },
        icon: const Icon(
          Icons.close,
          color: Colors.white,
        ),
      ),
      title: const Text(
        "Log a Symptom",
        style: TextStyle(
          fontSize: 18,
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {},
          child: const Text(
            "Save",
            style: TextStyle(
              color: Colors.white,
              fontSize: 16
            ),
          ),
        )
      ],
    );
  }

  Widget _buildBody() {
    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            height: 200,
            alignment: Alignment.bottomCenter,
            decoration: const BoxDecoration(
              image: DecorationImage(
                  image: AssetImage(
                      "assets/welcome1.jpg"
                  ),
                  fit: BoxFit.cover
              ),
            ),
          ),
          Container(
            height: 50,
            color: Colors.grey,
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.only(left: 15),
            child: const Text(
              'Log an occurrence of:',
              style: TextStyle(
                fontSize: 16,
              ),
            ),
          ),
          const SizedBox(height: 10,),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            margin: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.black12, width: 2)
            ),
            child: const Text(
              "ajbdj",
              style: TextStyle(
                fontSize: 18
              ),
            ),
          ),
          const SizedBox(height: 10,),
          Container(
            height: 50,
            color: Colors.grey,
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.only(left: 15),
            child: const Text(
              'Severity:',
              style: TextStyle(
                fontSize: 16,
              ),
            ),
          ),
          Container(
            color: Colors.white,
            child: Column(
              children: [
                ListTile(
                  visualDensity: const VisualDensity(vertical: -2, horizontal: 0),
                  leading: Radio(
                    value: Severity.none,
                    groupValue: selectedSeverity,
                    onChanged: (value) {
                      selectedSeverity = value!;
                      if (mounted) setState(() {});
                    },
                    fillColor: const MaterialStatePropertyAll(Colors.black45),
                    visualDensity: const VisualDensity(vertical: -2, horizontal: -2),
                  ),
                  title: const Text(
                    "None",
                    style: TextStyle(
                        fontSize: 18,
                        color: Colors.black45
                    ),
                  ),
                ),
                ListTile(
                  visualDensity: const VisualDensity(vertical: -2, horizontal: 0),
                  leading: Radio(
                    value: Severity.mild,
                    groupValue: selectedSeverity,
                    onChanged: (value) {
                      selectedSeverity = value!;
                      if (mounted) setState(() {});
                    },
                    fillColor: const MaterialStatePropertyAll(Colors.green),
                    visualDensity: const VisualDensity(vertical: -2, horizontal: -2),
                  ),
                  title: const Text(
                    "Mild",
                    style: TextStyle(
                        fontSize: 18,
                        color: Colors.green
                    ),
                  ),
                ),
                ListTile(
                  visualDensity: const VisualDensity(vertical: -2, horizontal: 0),
                  leading: Radio(
                    value: Severity.moderate,
                    groupValue: selectedSeverity,
                    onChanged: (value) {
                      selectedSeverity = value!;
                      if (mounted) setState(() {});
                    },
                    fillColor: const MaterialStatePropertyAll(Colors.yellow),
                    visualDensity: const VisualDensity(vertical: -2, horizontal: -2),
                  ),
                  title: const Text(
                    "Moderate",
                    style: TextStyle(
                        fontSize: 18,
                        color: Colors.yellow
                    ),
                  ),
                ),
                ListTile(
                  visualDensity: const VisualDensity(vertical: -2, horizontal: 0),
                  leading: Radio(
                    value: Severity.severe,
                    groupValue: selectedSeverity,
                    onChanged: (value) {
                      selectedSeverity = value!;
                      if (mounted) setState(() {});
                    },
                    fillColor: MaterialStatePropertyAll(Colors.deepOrange[900]),
                    visualDensity: const VisualDensity(vertical: -2, horizontal: -2),
                  ),
                  title: Text(
                    "Severe",
                    style: TextStyle(
                        fontSize: 18,
                        color: Colors.deepOrange[900]
                    ),
                  ),
                ),
              ],
            ),
          ),
          Container(
            height: 50,
            color: Colors.grey,
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.only(left: 15),
            child: const Text(
              'Date and Time:',
              style: TextStyle(
                fontSize: 16,
              ),
            ),
          ),
          const SizedBox(height: 10,),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            margin: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
                border: Border.all(color: Colors.black12, width: 2)
            ),
            child: const Text(
              "Apr 23, 2023 18:27",
              style: TextStyle(
                  fontSize: 18
              ),
            ),
          ),
          const SizedBox(height: 10,),
          Container(
            height: 50,
            color: Colors.grey,
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.only(left: 15),
            child: const Text(
              'Notes - Record symptom details including duration:',
              style: TextStyle(
                fontSize: 16,
              ),
            ),
          ),
          Container(
            color: Colors.white,
            padding: const EdgeInsets.all(10),
            child: TextFormField(
              decoration: const InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.black12, width: 2),
                  borderRadius: BorderRadius.zero
                ),
                focusedBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: Colors.black12, width: 2),
                    borderRadius: BorderRadius.zero
                ),
              ),
            ),
          ),
          Container(
            color: Colors.grey,
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.all(15),
            child: const Text(
              'If you would like to associate this symptom with a question, first save this symptom, and them return to the My Health page to create a new question.',
              style: TextStyle(
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

enum Severity {none, mild, moderate, severe}