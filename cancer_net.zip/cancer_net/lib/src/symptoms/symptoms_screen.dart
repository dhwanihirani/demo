import 'package:cancer_net/core/constColor.dart';
import 'package:cancer_net/core/constRoute.dart';
import 'package:flutter/material.dart';

class SymptomsScreen extends StatefulWidget {
  const SymptomsScreen({Key? key}) : super(key: key);

  @override
  State<SymptomsScreen> createState() => _SymptomsScreenState();
}

class _SymptomsScreenState extends State<SymptomsScreen> {

  String? symptomsName;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(),
      body: _buildBody(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: const Text(
        "Log a Symptom",
        style: TextStyle(
          fontSize: 18,
        ),
      ),
      actions: [
        TextButton(
          onPressed: () {},
          child: const Text(
            "Edit",
            style: TextStyle(
              fontSize: 14,
              color: Colors.white
            ),
          ),
        )
      ],
    );
  }

  Widget _buildBody() {
    return SingleChildScrollView(
      child: Column(
        children: [
          Container(
            height: 250,
            alignment: Alignment.bottomCenter,
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage(
                  "assets/welcome1.jpg"
                ),
                fit: BoxFit.cover
              ),
            ),
            child: Container(
              height: 90,
              color: Colors.grey,
              alignment: Alignment.center,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Text(
                    'What symptom are you experiencing?',
                    style: TextStyle(
                      fontSize: 16,
                    ),
                  ),
                  Text(
                    'Select a symptom from the list below, or add a new symptom:',
                    style: TextStyle(
                      fontSize: 14,
                    ),
                  ),
                ],
              ),
            ),
          ),
          Container(
            color: Colors.white,
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.all(10),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: List.generate(15, (index) =>
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    Text(
                      "Headache",
                      style: TextStyle(
                        fontSize: 20
                      ),
                    ),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
            ),
          ),
          Container(
            color: Colors.grey,
            padding: const EdgeInsets.all(10),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  "If you don't see your symptom listed, you may enter it here:",
                  style: TextStyle(
                    fontSize: 18
                  ),
                ),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        onChanged: (value) {
                          symptomsName = value;
                          if (mounted) setState(() {});
                        },
                        decoration: const InputDecoration(
                          contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 0),
                          enabledBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: Colors.black, width: 1),
                          ),
                          focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: ConstColour.bgIconColor, width: 2)
                          ),
                          hintText: "Name of Symptom",
                          hintStyle: TextStyle(
                            fontSize: 16,
                            color: Colors.black45
                          )
                        ),
                      ),
                    ),
                    if (symptomsName != null && symptomsName != "")...[
                      IconButton(
                        onPressed: () {
                          Navigator.of(context).pushNamed(ConstRoute.addSymptoms);
                        },
                        visualDensity: const VisualDensity(vertical: -2, horizontal: 0),
                        padding: EdgeInsets.zero,
                        icon: const Icon(
                          Icons.send_rounded,
                        ),
                      )
                    ],
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
