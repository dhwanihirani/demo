import 'package:flutter/material.dart';
import '../../core/constColor.dart';
import '../../core/constFonts.dart';
import '../../core/constRoute.dart';

class BookmarksPage extends StatefulWidget {
  const BookmarksPage({Key? key}) : super(key: key);

  @override
  State<BookmarksPage> createState() => _BookmarksPageState();
}

class _BookmarksPageState extends State<BookmarksPage> with SingleTickerProviderStateMixin{

  List<Tab> myTabs = <Tab>[
    const Tab(text: 'ALL',),
    const Tab(text: 'ARTICLES',),
    const Tab(text: 'PODCASTS',),
    const Tab(text: 'VIDEO',),
  ];

  TabController? controller;
  int? tabIndex = 0;

  final List<AllBookmarksModel> allBookmarkList = <AllBookmarksModel>[
    AllBookmarksModel(lable: 'news', title: "About Us" , des: "Find out more about this patient education website, including its high quality content review process, its history and awards, and main areas of navigation.", url: "https://www.cancer.net/about-us"),
    AllBookmarksModel(lable: 'news', title: "About Cancer.Net" ,des: "About Cancer.Net", url: "https://www.cancer.net/about-us"),
    AllBookmarksModel(lable: 'news', title: "About Us", des: "About Us", url: "https://www.cancer.net/about-us"),
  ];

  final List<AllBookmarksModel> articlesBookmarkList = <AllBookmarksModel>[
    AllBookmarksModel(lable: 'news', title: "About Us" , des: "Find out more about this patient education website, including its high quality content review process, its history and awards, and main areas of navigation.", url: "https://www.cancer.net/about-us"),
    AllBookmarksModel(lable: 'news', title: "About Cancer.Net" ,des: "About Cancer.Net", url: "https://www.cancer.net/about-us"),
    AllBookmarksModel(lable: 'news', title: "About Us", des: "About Us", url: "https://www.cancer.net/about-us"),
  ];

  final List<AllBookmarksModel> podcastsBookmarkList = <AllBookmarksModel>[];

  final List<AllBookmarksModel> videoBookmarkList = <AllBookmarksModel>[];

  @override
  void initState() {
    controller = TabController(vsync: this, length: myTabs.length,);
    super.initState();
  }

  @override
  void dispose() {
    controller!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
        child: Scaffold(
          backgroundColor: ConstColour.bgColor,
          appBar: AppBar(
            backgroundColor: ConstColour.appBarColor,
            title: const Text('Bookmarks',
            style: TextStyle(
            color: ConstColour.appBarFontColor,
            fontFamily: ConstFont.primaryFontFamily,
            fontWeight: FontWeight.bold,
            fontSize: 20,
            ),
            ),
            bottom: TabBar(
              indicatorColor: ConstColour.bgIconColor,
              indicatorSize: TabBarIndicatorSize.tab,
              labelColor: ConstColour.appBarFontColor,
              unselectedLabelColor: ConstColour.appBarFontColor,
              labelStyle: const TextStyle(
                fontFamily: ConstFont.primaryFontFamily,
                fontWeight: FontWeight.w700,
                fontSize: 15,
              ),
              onTap: (value){
                setState(() {
                  tabIndex = controller!.index;
                });
              },
              controller: controller,
              tabs: const [
                Tab(text: 'ALL',),
                Tab(text: 'ARTICLES',),
                Tab(text: 'PODCASTS',),
                Tab(text: 'VIDEO',),
              ],
            ),
          ),
          body: TabBarView(
            controller: controller,
            children: [
              Padding(
                padding: const EdgeInsets.all(10),
                child: allBookmarkList.isNotEmpty ? ListView.builder(
                  itemCount: allBookmarkList.length,
                  shrinkWrap: true,
                  itemBuilder: (context, index){
                    return buildListTile(
                        title: '${allBookmarkList[index].title}',
                        des: '${allBookmarkList[index].des}',
                        onTap: (){Navigator.of(context).pushNamed(ConstRoute.cancerWebViewPage,arguments: ['bookmarks','${allBookmarkList[index].title}','${allBookmarkList[index].url}']);},
                    );
                  }) : buildContainer(),
              ),
              Padding(
                padding: const EdgeInsets.all(10),
                child: articlesBookmarkList.isNotEmpty ? ListView.builder(
                    itemCount: articlesBookmarkList.length,
                    shrinkWrap: true,
                    itemBuilder: (context, index){
                      return buildListTile(
                          title: '${articlesBookmarkList[index].title}',
                          des: '${articlesBookmarkList[index].des}',
                        onTap: (){Navigator.of(context).pushNamed(ConstRoute.cancerWebViewPage,arguments: ['bookmarks','${articlesBookmarkList[index].title}','${articlesBookmarkList[index].url}']);},
                      );
                    }) : buildContainer(),
              ),
              Padding(
                padding: const EdgeInsets.all(10),
                child: podcastsBookmarkList.isNotEmpty ? ListView.builder(
                    itemCount: podcastsBookmarkList.length,
                    shrinkWrap: true,
                    itemBuilder: (context, index){
                      return buildListTile(
                          title: '${podcastsBookmarkList[index].title}',
                          des: '${podcastsBookmarkList[index].des}',
                        onTap: (){Navigator.of(context).pushNamed(ConstRoute.cancerWebViewPage,arguments: ['bookmarks','${podcastsBookmarkList[index].title}','${podcastsBookmarkList[index].url}']);},
                      );
                    }) : buildContainer(),
              ),
              Padding(
                padding: const EdgeInsets.all(10),
                child: videoBookmarkList.isNotEmpty ? ListView.builder(
                    itemCount: videoBookmarkList.length,
                    shrinkWrap: true,
                    itemBuilder: (context, index){
                      return buildListTile(
                          title: '${videoBookmarkList[index].title}',
                          des: '${videoBookmarkList[index].des}',
                        onTap: (){Navigator.of(context).pushNamed(ConstRoute.cancerWebViewPage,arguments: ['bookmarks','${videoBookmarkList[index].title}','${videoBookmarkList[index].url}']);},
                      );
                    }) : buildContainer(),
              ),
            ],
          ),
        )
    );
  }
}

Widget buildContainer(){
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: const [
      Text('No items have been bookmarked.',
      style: TextStyle(
        fontSize: 15,
        fontWeight: FontWeight.normal,
        fontFamily: ConstFont.primaryFontFamily,
        color: ConstColour.secondFontColor,
      ),
      ),
      SizedBox(height: 20),
      Text('You may bookmark news articles, videos, podcasts, information articles, and cancer types.',
        style: TextStyle(
          fontSize: 15,
          fontWeight: FontWeight.normal,
          fontFamily: ConstFont.primaryFontFamily,
          color: ConstColour.secondFontColor,
        ),
      )
    ],
  );
}

Widget buildListTile({String? title, String? des, GestureTapCallback? onTap, }){
  return Column(
    children: [
      const SizedBox(height: 8,),
      ListTile(
        onTap: onTap,
        shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(4)),),
        tileColor: ConstColour.white,
        leading: const Icon(Icons.my_library_books_outlined,size: 35),
        title: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Text('$title',style:const TextStyle(
            color: ConstColour.primaryFontColor,
            fontSize: 16,
            fontWeight: FontWeight.bold,
            fontFamily: ConstFont.primaryFontFamily,
          ),
          ),
        ),
        subtitle: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            des != null && des != 'null'? Flexible(
              child: Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: Text(des,style:const TextStyle(
                  color: ConstColour.secondFontColor,
                  fontSize: 14,
                  fontWeight: FontWeight.normal,
                  fontFamily: ConstFont.primaryFontFamily,
                ),
                ),
              ),
            ): const SizedBox(),
            Align(
              alignment: Alignment.center,
              child: Container(
                height: 20,
                width: 20,
                alignment: Alignment.center,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: ConstColour.bgIconColor,
                ),
                child: const Icon(Icons.arrow_forward_ios,size: 12,color: ConstColour.primaryColor),
              ),
            )
          ],
        ),
      ),
    ],
  );
}

class AllBookmarksModel{
  String? title;
  String? url;
  String? des;
  String? lable;

  AllBookmarksModel({this.title,this.url,this.des,this.lable});
}