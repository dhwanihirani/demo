import 'package:cancer_net/core/constColor.dart';
import 'package:cancer_net/core/constFonts.dart';
import 'package:flutter/material.dart';

import '../../common/checkBox.dart';
import '../../common/showToast.dart';
import '../../core/constRoute.dart';

class WelcomeSecondPage extends StatefulWidget {
  const WelcomeSecondPage({Key? key}) : super(key: key);

  @override
  State<WelcomeSecondPage> createState() => _WelcomeSecondPageState();
}

class _WelcomeSecondPageState extends State<WelcomeSecondPage> {

  int? isCheckInd;
  final List<CheckBoxModel> checkDataList = <CheckBoxModel>[
    CheckBoxModel(id: 1,title: 'I have recently been diagnosed with cancer',isCheck: false),
    CheckBoxModel(id: 2,title: 'I am currently in treatment for cancer',isCheck: false),
    CheckBoxModel(id: 3,title: 'I have completed cancer treatment',isCheck: false),
    CheckBoxModel(id: 4,title: 'I have a family member or friend with cancer',isCheck: false),
    CheckBoxModel(id: 5,title: 'Other',isCheck: false),
    CheckBoxModel(id: 5,title: 'I prefer not to answer',isCheck: false),
  ];

  @override
  Widget build(BuildContext context) {
    return MediaQuery(data:  MediaQuery.of(context).copyWith(textScaleFactor: 1),
        child: Scaffold(
          backgroundColor: ConstColour.bgColor,
          appBar: AppBar(
            backgroundColor: ConstColour.appBarColor,
            title: const Text('Welcome',
              style: TextStyle(
                color: ConstColour.appBarFontColor,
                fontFamily: ConstFont.primaryFontFamily,
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
            actions: [TextButton(
                onPressed: (){
                  Navigator.of(context).pushNamedAndRemoveUntil(ConstRoute.welcomeTourPage,(route) => false,);
                },
                child: const Text('SKIP',style: TextStyle(
                  color: ConstColour.appBarFontColor,
                  fontFamily: ConstFont.primaryFontFamily,
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                ),)
            )],
          ),
          body: Column(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(vertical: 15),
                color: ConstColour.white,
                alignment: Alignment.center,
                child: Column(
                  children: [
                    const Text('Cancer.Net®',
                      style: TextStyle(
                        color: ConstColour.bgIconColor,
                        fontFamily: ConstFont.primaryFontFamily,
                        fontWeight: FontWeight.bold,
                        fontSize: 50,
                      ),
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Text('ASCO',
                          style: TextStyle(
                            color: ConstColour.primaryColor,
                            fontFamily: ConstFont.primaryFontFamily,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        Text(' | ',
                          style: TextStyle(
                            color: ConstColour.bgIconColor,
                            fontFamily: ConstFont.primaryFontFamily,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        Text('KNOWLEDGE CONQUERS CANCER',
                          style: TextStyle(
                            color: ConstColour.primaryFontColor,
                            fontFamily: ConstFont.primaryFontFamily,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      margin: const EdgeInsets.all(15),
                      decoration: const BoxDecoration(
                        color: ConstColour.white,
                        borderRadius: BorderRadius.all(Radius.circular(4)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text("Before we begin, let's start by learning a little about you. We'll use your answers to the following questions to create personalized content suggestions for you.",
                            style: TextStyle(
                              color: Colors.black,
                              fontFamily: ConstFont.primaryFontFamily,
                              fontWeight: FontWeight.normal,
                              fontSize: 14,
                            ),
                          ),
                          SizedBox(
                            height: 15,
                          ),
                          Text("Select one of the following options:",
                            style: TextStyle(
                              color: Colors.black,
                              fontFamily: ConstFont.primaryFontFamily,
                              fontWeight: FontWeight.normal,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.all(10),
                      margin: const EdgeInsets.all(15),
                      decoration: const BoxDecoration(
                        color: ConstColour.white,
                        borderRadius: BorderRadius.all(Radius.circular(4)),
                      ),
                      child: ListView.builder(
                          physics: const NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          //padding: const EdgeInsets.all(10),
                          itemCount: checkDataList.length,
                          itemBuilder: (context, index){
                            return buildCheckBoxList(
                              title: checkDataList[index].title,
                              value: checkDataList[index].isCheck,
                              onChange: (value){
                                //if(isCheckInd == index){
                                setState(() {
                                  value == true ? isCheckInd = index : isCheckInd = null;
                                  checkDataList[index].isCheck = value;
                                });
                                //}
                              }
                            );
                          }),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(15),
                      child: TextButton(
                        style: TextButton.styleFrom(
                            elevation: 2,
                            backgroundColor: Colors.amber),
                        onPressed: (){
                          if(isCheckInd != null){
                            Navigator.of(context).pushNamedAndRemoveUntil(ConstRoute.welcomeThirdPage,arguments: [isCheckInd],(route) => false,);
                          }else{
                            showToast(msg: 'Please choose an option.');
                          }
                        },
                        child: const Text('Next',
                          style: TextStyle(
                            color: ConstColour.primaryFontColor,
                            fontFamily: ConstFont.primaryFontFamily,
                            fontWeight: FontWeight.w500,
                            fontSize: 18,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                    const SizedBox(height: 25,)
                  ],
                ),
              ),
            ],
          ),
        )
    );
  }
}

