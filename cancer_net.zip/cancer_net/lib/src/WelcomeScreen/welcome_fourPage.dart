import 'package:cancer_net/core/constColor.dart';
import 'package:cancer_net/core/constFonts.dart';
import 'package:flutter/material.dart';

import '../../common/checkBox.dart';
import '../../common/showToast.dart';
import '../../core/constRoute.dart';

class WelcomeFourPage extends StatefulWidget {
  const WelcomeFourPage({Key? key,}) : super(key: key);

  @override
  State<WelcomeFourPage> createState() => _WelcomeFourPageState();
}

class _WelcomeFourPageState extends State<WelcomeFourPage> {

  int? isCheckInd;

  @override
  Widget build(BuildContext context) {
    return MediaQuery(data:  MediaQuery.of(context).copyWith(textScaleFactor: 1),
        child: Scaffold(
          backgroundColor: ConstColour.bgColor,
          appBar: AppBar(
            backgroundColor: ConstColour.appBarColor,
            title: const Text('Welcome',
              style: TextStyle(
                color: ConstColour.appBarFontColor,
                fontFamily: ConstFont.primaryFontFamily,
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
            actions: [TextButton(
                onPressed: (){
                  Navigator.of(context).pushNamedAndRemoveUntil(ConstRoute.welcomeTourPage,(route) => false,);
                },
                child: const Text('SKIP',style: TextStyle(
                  color: ConstColour.appBarFontColor,
                  fontFamily: ConstFont.primaryFontFamily,
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                ),)
            )],
          ),
          body: Column(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(vertical: 15),
                color: ConstColour.white,
                alignment: Alignment.center,
                child: Column(
                  children: [
                    const Text('Cancer.Net®',
                      style: TextStyle(
                        color: ConstColour.bgIconColor,
                        fontFamily: ConstFont.primaryFontFamily,
                        fontWeight: FontWeight.bold,
                        fontSize: 50,
                      ),
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Text('ASCO',
                          style: TextStyle(
                            color: ConstColour.primaryColor,
                            fontFamily: ConstFont.primaryFontFamily,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        Text(' | ',
                          style: TextStyle(
                            color: ConstColour.bgIconColor,
                            fontFamily: ConstFont.primaryFontFamily,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        Text('KNOWLEDGE CONQUERS CANCER',
                          style: TextStyle(
                            color: ConstColour.primaryFontColor,
                            fontFamily: ConstFont.primaryFontFamily,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      margin: const EdgeInsets.all(15),
                      decoration: const BoxDecoration(
                        color: ConstColour.white,
                        borderRadius: BorderRadius.all(Radius.circular(4)),
                      ),
                      child: const Text("Which type of cancer are you most interested in learning more about?",
                        style: TextStyle(
                          color: Colors.black,
                          fontFamily: ConstFont.primaryFontFamily,
                          fontWeight: FontWeight.normal,
                          fontSize: 14,
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.all(10),
                      margin: const EdgeInsets.all(15),
                      decoration: const BoxDecoration(
                        color: ConstColour.white,
                        borderRadius: BorderRadius.all(Radius.circular(4)),
                      ),
                      child: ListView.builder(
                          physics: const NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          //padding: const EdgeInsets.all(10),
                          itemCount: checkDataList.length ,
                          itemBuilder: (context, index){
                            return buildCheckBoxList(
                                title:checkDataList[index].title ,
                                value:checkDataList[index].isCheck,
                                onChange: (value){
                                  setState(() {
                                    checkDataList[index].isCheck = value;
                                  });
                                  //if(isCheckInd == index){

                                  }
                                  //}
                            );
                          }),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(15),
                      child: TextButton(
                        style: TextButton.styleFrom(
                            elevation: 2,
                            backgroundColor: Colors.amber),
                        onPressed: (){
                          int isIndCheck = checkDataList.indexWhere((e) => e.isCheck == true);
                          if(isIndCheck != -1){
                            Navigator.of(context).pushNamedAndRemoveUntil(ConstRoute.welcomeTourPage,(route) => false,);
                          }else{
                            showToast(msg: 'Please choose an option.');
                          }
                        },
                        child: const Text('Start the tour',
                          style: TextStyle(
                            color: ConstColour.primaryFontColor,
                            fontFamily: ConstFont.primaryFontFamily,
                            fontWeight: FontWeight.w500,
                            fontSize: 18,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                    const SizedBox(height: 25,)
                  ],
                ),
              ),
            ],
          ),
        )
    );
  }

  final List<CheckBoxModel> checkDataList = <CheckBoxModel>[
    CheckBoxModel(title: 'Adenoid Cystic Carcinoma',isCheck: false),
    CheckBoxModel(title: 'Adrenal Gland Tumor',isCheck: false),
    CheckBoxModel(title: 'Amyloidosis',isCheck: false),
    CheckBoxModel(title: 'Anal Cancer',isCheck: false),
    CheckBoxModel(title: 'Appendix Cancer',isCheck: false),
    CheckBoxModel(title: 'Astrocytoma - Childhood',isCheck: false),
    CheckBoxModel(title: 'Bile Duct Cancer (Cholangiocarcinoma)',isCheck: false),
    CheckBoxModel(title: 'Bladder Cancer',isCheck: false),
    CheckBoxModel(title: 'Bone Cancer (Sarcoma of Bone)',isCheck: false),
    CheckBoxModel(title: 'Brain Stem Glioma - Childhood',isCheck: false),
    CheckBoxModel(title: 'Brain Tumor',isCheck: false),
    CheckBoxModel(title: 'Breast Cancer',isCheck: false),
    CheckBoxModel(title: 'Breast Cancer - Inflammatory',isCheck: false),
    CheckBoxModel(title: 'Breast Cancer - Metastatic',isCheck: false),
    CheckBoxModel(title: 'Breast Cancer, Male',isCheck: false),
    CheckBoxModel(title: 'Central Nervous System Tumors (Brainand Spinal Cord) - Childhood',isCheck: false),
    CheckBoxModel(title: 'Cervical Cancer',isCheck: false),
    CheckBoxModel(title: 'Childhood Cancer',isCheck: false),
    CheckBoxModel(title: 'Colorectal Cancer',isCheck: false),
    CheckBoxModel(title: 'Craniopharyngioma - Childhood',isCheck: false),
    CheckBoxModel(title: 'Desmoid Tumor',isCheck: false),
    CheckBoxModel(title: 'Desmoplastic Infantile Ganglioglioma, Childhood Tumor',isCheck: false),
    CheckBoxModel(title: 'Ependymoma Childhood',isCheck: false),
    CheckBoxModel(title: 'Esophageal Cancer',isCheck: false),
    CheckBoxModel(title: 'Ewing Sarcoma - Childhood and Adolescence',isCheck: false),
    CheckBoxModel(title: 'Eye Melanoma',isCheck: false),
    CheckBoxModel(title: 'Eyelid Cancer',isCheck: false),
    CheckBoxModel(title: 'Gallbladder Cancer',isCheck: false),
    CheckBoxModel(title: 'Gastrointestinal Stromal Tumor - GIST',isCheck: false),
    CheckBoxModel(title: 'Germ Cell Tumor - Childhood',isCheck: false),
    CheckBoxModel(title: 'Gestational Trophoblastic Disease',isCheck: false),
    CheckBoxModel(title: 'Head and Neck Cancer',isCheck: false),
    CheckBoxModel(title: 'HIV/AIDS-Related Cancer',isCheck: false),
    CheckBoxModel(title: 'Kidney Cancer',isCheck: false),
    CheckBoxModel(title: 'Laryngeal and Hypopharyngeal Cancer',isCheck: false),
    CheckBoxModel(title: 'Leukemia - Acute Lymphoblastic - ALL- Childhood',isCheck: false),
    CheckBoxModel(title: 'Leukemia - Acute Lymphocytic - ALL',isCheck: false),
    CheckBoxModel(title: 'Leukemia Acute Myeloid - AML',isCheck: false),
    CheckBoxModel(title: 'Leukemia - Acute Myeloid - AML - Childhood',isCheck: false),
    CheckBoxModel(title: 'Leukemia B-cell Prolymphocytic Leukemia and Hairy Cell Leukemia',isCheck: false),
    CheckBoxModel(title: 'Leukemia Chronic Lymphocytic - CLL',isCheck: false),
    CheckBoxModel(title: 'Leukemia Chronic Myeloid - CML',isCheck: false),
    CheckBoxModel(title: 'Leukemia Chronic T-Cell Lymphocytic',isCheck: false),
    CheckBoxModel(title: 'Leukemia Eosinophilic',isCheck: false),
    CheckBoxModel(title: 'Liver Cancer',isCheck: false),
    CheckBoxModel(title: 'Lung Cancer Non-Small Cell',isCheck: false),
    CheckBoxModel(title: 'Lung Cancer-Small Cell',isCheck: false),
    CheckBoxModel(title: 'Lymphoma Hodgkin',isCheck: false),
    CheckBoxModel(title: 'Lymphoma Hodgkin - Childhood',isCheck: false),
    CheckBoxModel(title: 'Lymphoma Non-Hodgkin',isCheck: false),
    CheckBoxModel(title: 'Lymphoma Non-Hodgkin - Childhood',isCheck: false),
    CheckBoxModel(title: 'Mastocytosis',isCheck: false),
    CheckBoxModel(title: 'Medulloblastoma - Childhood',isCheck: false),
    CheckBoxModel(title: 'Melanoma',isCheck: false),
    CheckBoxModel(title: 'Meningioma',isCheck: false),
    CheckBoxModel(title: 'Mesothelioma',isCheck: false),
    CheckBoxModel(title: 'Multiple Myeloma',isCheck: false),
    CheckBoxModel(title: 'Myelodysplastic Syndromes - MDS',isCheck: false),
    CheckBoxModel(title: 'Nasal Cavity and Paranasal Sinus Cancer',isCheck: false),
    CheckBoxModel(title: 'Nasopharyngeal Cancer',isCheck: false),
    CheckBoxModel(title: 'Neuroblastoma - Childhood',isCheck: false),
    CheckBoxModel(title: 'Neuroendocrine Tumor of the Gastrointestinal Tract',isCheck: false),
    CheckBoxModel(title: 'Neuroendocrine Tumor of the Lung',isCheck: false),
    CheckBoxModel(title: 'Neuroendocrine Tumor of the Pancreas',isCheck: false),
    CheckBoxModel(title: 'Neuroendocrine Tumors',isCheck: false),
    CheckBoxModel(title: 'Oral and Oropharyngeal Cancer',isCheck: false),
    CheckBoxModel(title: 'Osteosarcoma - Childhood and Adolescence',isCheck: false),
    CheckBoxModel(title: 'Ovarian, Fallopian Tube, and Peritoneal Cancer',isCheck: false),
    CheckBoxModel(title: 'Pancreatic Cancer',isCheck: false),
    CheckBoxModel(title: 'Parathyroid Cancer',isCheck: false),
    CheckBoxModel(title: 'Penile Cancer',isCheck: false),
    CheckBoxModel(title: 'Pheochromocytoma and Paraganglioma',isCheck: false),
    CheckBoxModel(title: 'Pituitary Gland Tumor',isCheck: false),
    CheckBoxModel(title: 'Pleuropulmonary Blastoma - Childhood',isCheck: false),
    CheckBoxModel(title: 'Prostate Cancer',isCheck: false),
    CheckBoxModel(title: 'Retinoblastoma - Childhood',isCheck: false),
    CheckBoxModel(title: 'Rhabdomyosarcoma - Childhood',isCheck: false),
    CheckBoxModel(title: 'Salivary Gland Cancer',isCheck: false),
    CheckBoxModel(title: 'Sarcoma Kaposi',isCheck: false),
    CheckBoxModel(title: 'Sarcomas, Soft Tissue',isCheck: false),
    CheckBoxModel(title: 'Skin Cancer (Non-Melanoma)',isCheck: false),
    CheckBoxModel(title: 'Small Bowel Cancer',isCheck: false),
    CheckBoxModel(title: 'Stomach Cancer',isCheck: false),
    CheckBoxModel(title: 'Testicular Cancer',isCheck: false),
    CheckBoxModel(title: 'Thymoma and Thymic Carcinoma',isCheck: false),
    CheckBoxModel(title: 'Thyroid Cancer',isCheck: false),
    CheckBoxModel(title: 'Unknown Primary',isCheck: false),
    CheckBoxModel(title: 'Uterine Cancer',isCheck: false),
    CheckBoxModel(title: 'Vaginal Cancer',isCheck: false),
    CheckBoxModel(title: 'Vulvar Cancer',isCheck: false),
    CheckBoxModel(title: 'Waldenstrom Macroglobulinemia (Lymphoplasmacytic Lymphoma)',isCheck: false),
    CheckBoxModel(title: 'Wilms Tumor - Childhood',isCheck: false),
  ];
}

