import 'package:cancer_net/core/constColor.dart';
import 'package:cancer_net/core/constFonts.dart';
import 'package:cancer_net/core/constRoute.dart';
import 'package:flutter/material.dart';

class WelcomePage extends StatefulWidget {
  const WelcomePage({Key? key}) : super(key: key);

  @override
  State<WelcomePage> createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
  @override
  Widget build(BuildContext context) {
    return MediaQuery(data:  MediaQuery.of(context).copyWith(textScaleFactor: 1),
        child: Scaffold(
          backgroundColor: ConstColour.bgColor,
          appBar: AppBar(
            backgroundColor: ConstColour.appBarColor,
            title: const Text('Welcome',
              style: TextStyle(
                color: ConstColour.appBarFontColor,
                fontFamily: ConstFont.primaryFontFamily,
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
            actions: [TextButton(
                  onPressed: (){
                    Navigator.of(context).pushNamedAndRemoveUntil(ConstRoute.welcomeTourPage,(route) => false,);
                  },
                  child: const Text('SKIP',style: TextStyle(
                    color: ConstColour.appBarFontColor,
                    fontFamily: ConstFont.primaryFontFamily,
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                  ),)
              )],
          ),
          body: Column(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(vertical: 15),
                color: ConstColour.white,
                alignment: Alignment.center,
                child: Column(
                  children: [
                    const Text('Cancer.Net®',
                      style: TextStyle(
                        color: ConstColour.bgIconColor,
                        fontFamily: ConstFont.primaryFontFamily,
                        fontWeight: FontWeight.bold,
                        fontSize: 50,
                      ),
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Text('ASCO',
                          style: TextStyle(
                            color: ConstColour.primaryColor,
                            fontFamily: ConstFont.primaryFontFamily,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        Text(' | ',
                          style: TextStyle(
                            color: ConstColour.bgIconColor,
                            fontFamily: ConstFont.primaryFontFamily,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        Text('KNOWLEDGE CONQUERS CANCER',
                          style: TextStyle(
                            color: ConstColour.primaryFontColor,
                            fontFamily: ConstFont.primaryFontFamily,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      margin: const EdgeInsets.all(15),
                      decoration: const BoxDecoration(
                        color: ConstColour.white,
                        borderRadius: BorderRadius.all(Radius.circular(4)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text('TIMELY. TRUSTED. COMPASSIONATE.',
                            style: TextStyle(
                              color: Colors.black,
                              fontFamily: ConstFont.primaryFontFamily,
                              fontWeight: FontWeight.w500,
                              fontSize: 16,
                            ),
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Text("Cancer.Net Mobile offers comprehensive information and health management tools for people with cancer, families, and caregivers, from the American Society of Clinical Oncology (ASCO), the voice of the world's oncology professionals.",
                            style: TextStyle(
                              color: Colors.black,
                              fontFamily: ConstFont.primaryFontFamily,
                              fontWeight: FontWeight.normal,
                              fontSize: 14,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(15),
                      child: TextButton(
                        style: TextButton.styleFrom(
                            elevation: 2,
                            backgroundColor: Colors.amber),
                        onPressed: (){
                          Navigator.of(context).pushNamedAndRemoveUntil(ConstRoute.welcomeSecondPage,(route) => false,);
                        },
                        child: const Text('Tour this app and personalize your experience',
                          style: TextStyle(
                            color: ConstColour.primaryFontColor,
                            fontFamily: ConstFont.primaryFontFamily,
                            fontWeight: FontWeight.w500,
                            fontSize: 16,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const Padding(
                padding: EdgeInsets.all(15),
                child: Text('You may access this tour at any time; it is located under the About tab.',
                  style: TextStyle(
                    color: ConstColour.primaryFontColor,
                    fontFamily: ConstFont.primaryFontFamily,
                    fontWeight: FontWeight.w500,
                    fontSize: 14,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        )
    );
  }
}
