import 'package:cancer_net/core/constColor.dart';
import 'package:cancer_net/core/constFonts.dart';
import 'package:flutter/material.dart';

import '../../common/checkBox.dart';
import '../../core/constRoute.dart';

class WelcomeThirdPage extends StatefulWidget {
  const WelcomeThirdPage({Key? key,this.id}) : super(key: key);

  final int? id;

  @override
  State<WelcomeThirdPage> createState() => _WelcomeThirdPageState();
}

class _WelcomeThirdPageState extends State<WelcomeThirdPage> {

  int? isCheckInd;
  final List<CheckBoxModel> checkDataList = <CheckBoxModel>[
    CheckBoxModel(id: 1,title: 'Information for people over 65',isCheck: false),
    CheckBoxModel(id: 2,title: 'Information for young adults and teenagers',isCheck: false),
    CheckBoxModel(id: 3,title: 'Information for members of the LGBTQ+ community',isCheck: false),
    CheckBoxModel(id: 4,title: 'Information on clinical trials',isCheck: false),
    CheckBoxModel(id: 5,title: 'Information on managing the costs of cancer care',isCheck: false),
    CheckBoxModel(id: 6,title: 'Information on coping with emotions caused by a cancer diagnosis',isCheck: false),
    CheckBoxModel(id: 7,title: 'Information on coping with side effects of cancer treatment',isCheck: false),
    CheckBoxModel(id: 8,title: 'Information on fertility concerns and preservation',isCheck: false),
    CheckBoxModel(id: 9,title: 'I prefer not to answer',isCheck: false),
  ];

  final List<CheckBoxModel> checkSecondDataList = <CheckBoxModel>[
    CheckBoxModel(id: 1,title: 'Supporting a friend with cancer',isCheck: false),
    CheckBoxModel(id: 2,title: 'Caring for a spouse or partner with cancer',isCheck: false),
    CheckBoxModel(id: 3,title: 'Caring for a parent with cancer',isCheck: false),
    CheckBoxModel(id: 4,title: 'Caring for a child with cancer',isCheck: false),
    CheckBoxModel(id: 5,title: 'Long-distance caregiving',isCheck: false),
    CheckBoxModel(id: 6,title: 'Taking care of yourself as a caregiver',isCheck: false),
  ];

  @override
  Widget build(BuildContext context) {
    return MediaQuery(data:  MediaQuery.of(context).copyWith(textScaleFactor: 1),
        child: Scaffold(
          backgroundColor: ConstColour.bgColor,
          appBar: AppBar(
            backgroundColor: ConstColour.appBarColor,
            title: const Text('Welcome',
              style: TextStyle(
                color: ConstColour.appBarFontColor,
                fontFamily: ConstFont.primaryFontFamily,
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
            actions: [TextButton(
                onPressed: (){
                  Navigator.of(context).pushNamedAndRemoveUntil(ConstRoute.welcomeTourPage,(route) => false,);
                },
                child: const Text('SKIP',style: TextStyle(
                  color: ConstColour.appBarFontColor,
                  fontFamily: ConstFont.primaryFontFamily,
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                ),)
            )],
          ),
          body: Column(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(vertical: 15),
                color: ConstColour.white,
                alignment: Alignment.center,
                child: Column(
                  children: [
                    const Text('Cancer.Net®',
                      style: TextStyle(
                        color: ConstColour.bgIconColor,
                        fontFamily: ConstFont.primaryFontFamily,
                        fontWeight: FontWeight.bold,
                        fontSize: 50,
                      ),
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        Text('ASCO',
                          style: TextStyle(
                            color: ConstColour.primaryColor,
                            fontFamily: ConstFont.primaryFontFamily,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        Text(' | ',
                          style: TextStyle(
                            color: ConstColour.bgIconColor,
                            fontFamily: ConstFont.primaryFontFamily,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                        Text('KNOWLEDGE CONQUERS CANCER',
                          style: TextStyle(
                            color: ConstColour.primaryFontColor,
                            fontFamily: ConstFont.primaryFontFamily,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Expanded(
                child: ListView(
                  shrinkWrap: true,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      margin: const EdgeInsets.all(15),
                      decoration: const BoxDecoration(
                        color: ConstColour.white,
                        borderRadius: BorderRadius.all(Radius.circular(4)),
                      ),
                      child: const Text("Are you interested in any of the following topics?(select up to 3)",
                        style: TextStyle(
                          color: Colors.black,
                          fontFamily: ConstFont.primaryFontFamily,
                          fontWeight: FontWeight.normal,
                          fontSize: 14,
                        ),
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.all(10),
                      margin: const EdgeInsets.all(15),
                      decoration: const BoxDecoration(
                        color: ConstColour.white,
                        borderRadius: BorderRadius.all(Radius.circular(4)),
                      ),
                      child: ListView.builder(
                          physics: const NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          //padding: const EdgeInsets.all(10),
                          itemCount: widget.id != 3 ? checkDataList.length : checkSecondDataList.length,
                          itemBuilder: (context, index){
                            return buildCheckBoxList(
                                title: widget.id != 3 ? checkDataList[index].title : checkSecondDataList[index].title,
                                value: widget.id != 3 ? checkDataList[index].isCheck : checkSecondDataList[index].isCheck,
                                onChange: (value){
                                  //if(isCheckInd == index){
                                  setState(() {
                                    if(widget.id != 3){
                                      checkDataList[index].isCheck = value;
                                    }else{
                                      checkSecondDataList[index].isCheck = value;
                                    }
                                  });
                                  //}
                                }
                            );
                          }),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(15),
                      child: TextButton(
                        style: TextButton.styleFrom(
                            elevation: 2,
                            backgroundColor: Colors.amber),
                        onPressed: (){
                          Navigator.of(context).pushNamedAndRemoveUntil(ConstRoute.welcomeFourPage,(route) => false,);
                        },
                        child: const Text('Next',
                          style: TextStyle(
                            color: ConstColour.primaryFontColor,
                            fontFamily: ConstFont.primaryFontFamily,
                            fontWeight: FontWeight.w500,
                            fontSize: 18,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                    const SizedBox(height: 25,)
                  ],
                ),
              ),
            ],
          ),
        )
    );
  }
}

