import 'package:flutter/material.dart';
import '../../core/constColor.dart';
import '../../core/constFonts.dart';
import '../../core/constRoute.dart';

class AboutPage extends StatefulWidget {
  const AboutPage({Key? key}) : super(key: key);

  @override
  State<AboutPage> createState() => _AboutPageState();
}

class _AboutPageState extends State<AboutPage> {
  @override
  Widget build(BuildContext context) {
    return MediaQuery(
        data:  MediaQuery.of(context).copyWith(textScaleFactor: 1),
    child: Scaffold(
      backgroundColor: ConstColour.bgColor,
      appBar: AppBar(
        backgroundColor: ConstColour.appBarColor,
        title: const Text('About',
          style: TextStyle(
            color: ConstColour.appBarFontColor,
            fontFamily: ConstFont.primaryFontFamily,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(5),
        shrinkWrap: true,
        children: [
          buildListTile(title: 'About Us',onTap: (){Navigator.of(context).pushNamed(ConstRoute.aboutUsPage);}),
          buildListTile(title: 'Contact Us',onTap: (){Navigator.of(context).pushNamed(ConstRoute.contactUsPage);}),
          buildListTile(title: 'Privacy Policy and Terms of Use',onTap: (){Navigator.of(context).pushNamed(ConstRoute.privacyAndPolicyPage);}),
          buildListTile(title: 'Welcome to Cancer.Net Mobile',onTap: (){Navigator.of(context).pushNamed(ConstRoute.appRatePage);}),
          buildListTile(title: 'Help With This App',onTap: (){Navigator.of(context).pushNamed(ConstRoute.helpWithThisAppPage);}),
          buildListTile(title: 'Welcome Tour',onTap: (){Navigator.of(context).pushNamed(ConstRoute.welcomeTourPage);}),
        ],
      ),
    ),
    );
  }
  Widget buildListTile({String? title,GestureTapCallback? onTap}){
    return Column(
      children: [
        const SizedBox(height: 8,),
        ListTile(
            onTap: onTap,
            shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(4)),),
            tileColor: ConstColour.white,
            title:  Text('$title',style:const TextStyle(
              color: ConstColour.primaryFontColor,
              fontSize: 15,
              fontWeight: FontWeight.bold,
              fontFamily: ConstFont.primaryFontFamily,
            ),
            ),
            trailing: Container(
              height: 20,
              width: 20,
              alignment: Alignment.center,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: ConstColour.bgIconColor,
              ),
              child: const Icon(Icons.arrow_forward_ios,size: 12,color: ConstColour.primaryColor),
            )
        ),
      ],
    );
  }
}
