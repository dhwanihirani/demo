import 'package:flutter/material.dart';
import '../../core/constColor.dart';
import '../../core/constFonts.dart';
import '../../core/constRoute.dart';

class AppRatePage extends StatefulWidget {
  const AppRatePage({Key? key}) : super(key: key);

  @override
  State<AppRatePage> createState() => _AppRatePageState();
}

class _AppRatePageState extends State<AppRatePage> {
  @override
  Widget build(BuildContext context) {
    return MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaleFactor: 1),
      child: Scaffold(
        backgroundColor: const Color(0xFFFAFAFA),
        appBar: AppBar(
          backgroundColor: ConstColour.appBarColor,
          title: const Text('Welcome',
            style: TextStyle(
              color: ConstColour.appBarFontColor,
              fontFamily: ConstFont.primaryFontFamily,
              fontWeight: FontWeight.bold,
              fontSize: 19,
            ),
          ),
        ),
        body: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          shrinkWrap: true,
          children: [
             Center(
              child:
              buildText(
                des: "Cancer.Net®",
                fontWeight: FontWeight.bold,
                color: ConstColour.bgIconColor,
                fontSize: MediaQuery.of(context).size.width / 7,
              ),
            ),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children:  [
                Text('ASCO',
                  style: TextStyle(
                    color: ConstColour.primaryColor,
                    fontFamily: ConstFont.primaryFontFamily,
                    fontWeight: FontWeight.bold,
                    fontSize: MediaQuery.of(context).size.width / 25,
                    letterSpacing: 2.0,
                  ),
                ),
                buildText(
                  des: ' | ',
                  fontSize: MediaQuery.of(context).size.width / 24,
                  color: ConstColour.bgIconColor,
                  fontWeight: FontWeight.bold,
                ),
                Text('KNOWLEDGE CONQUERS CANCER',
                  style: TextStyle(
                    color: ConstColour.primaryFontColor,
                    fontFamily: ConstFont.primaryFontFamily,
                    fontWeight: FontWeight.w600,
                    fontSize: MediaQuery.of(context).size.width / 25,
                    letterSpacing: 2.0,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 15),
            buildText(des: "TIMELY. TRUSTED. COMPASSIONATE.", fontSize: 15, color: ConstColour.secondFontColor,fontWeight: FontWeight.normal),
            const SizedBox(height: 15),
            buildText(color: ConstColour.secondFontColor, fontWeight: FontWeight.normal, des: "Cancer.Net Mobile offers comprehensive information and health management tools for people with cancer, families, and caregivers, from the American Society of Clinical Oncology (ASCO), the voice of the world's oncology professionals.",fontSize: 15),
            const SizedBox(height: 20),
            Center(
              child: buildText(
                des: 'ASCO®',
                fontSize: MediaQuery.of(context).size.width / 8,
                color: ConstColour.primaryFontColor,
                fontWeight: FontWeight.bold,
              ),
            ),
            Center(
              child: buildText(
                des: 'AMERICAN SOCIETY OF CLINICAL ONCOLOGY',
                fontSize: 14,
                color: ConstColour.primaryFontColor,
                fontWeight: FontWeight.normal,
              ),
            ),
            Center(
              child: Text('KNOWLEDGE CONQUERS CANCER',
                style: TextStyle(
                  color: const Color(0xFF0575A5),
                  fontFamily: ConstFont.primaryFontFamily,
                  fontWeight: FontWeight.normal,
                  fontSize: MediaQuery.of(context).size.width / 25,
                  letterSpacing: 2.0,
                ),
              ),
            ),
            const SizedBox(height: 20),
            buildTextButton(title: "Rate This App"),
            const SizedBox(height: 5),
            buildTextButton(title: "Visit Cancer.Net"),
            const SizedBox(height: 5),
            buildTextButton(title: "Find a Doctor"),
          ],
        ),
      ),
    );
  }

  Widget buildText({String? des, double? fontSize, Color? color, FontWeight? fontWeight}){
    return Text('$des',
      style: TextStyle(
        color: color,
        fontFamily: ConstFont.primaryFontFamily,
        fontWeight: fontWeight,
        fontSize: fontSize,
      ),
    );
  }

  Widget buildTextButton({String? title, VoidCallback? onPressed}){
    return TextButton(onPressed: onPressed,
        style: ButtonStyle(backgroundColor: MaterialStateProperty.all(ConstColour.bgIconColor)),
        child: buildText(
            fontWeight: FontWeight.normal,
            color: const Color(0xFFFFFFF8),
            fontSize: 18,
            des: "$title"
        )
    );
  }
}
