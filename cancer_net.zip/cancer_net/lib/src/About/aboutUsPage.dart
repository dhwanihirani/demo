import 'package:flutter/material.dart';
import '../../core/constColor.dart';
import '../../core/constFonts.dart';
import '../../core/constRoute.dart';

class AboutUsPage extends StatefulWidget {
  const AboutUsPage({Key? key}) : super(key: key);

  @override
  State<AboutUsPage> createState() => _AboutUsPageState();
}

class _AboutUsPageState extends State<AboutUsPage> {

  bool isBookmark = false;

  final List<AboutUsModel> aboutUsList = <AboutUsModel>[
    AboutUsModel(title: "About Cancer.Net", subTitle: "Find out more about this patient education website, including its high quality content review process, its history and awards, and main areas of navigation."),
    AboutUsModel(title: "Cancer.Net Editorial Board", subTitle: "View more information about the Cancer.Net Editorial Board, who oversee the content on Cancer.Net."),
    AboutUsModel(title: "About ASCO", subTitle: "Learn more about the American Society of Clinical Oncology, the world's leading professional organization representing physicians of all oncology sub specialties who care for people with cancer."),
    AboutUsModel(title: "About Conquer Cancer ®, the ASCO Foundation", subTitle: "Discover more about the foundation supporting Cancer.Net"),
    AboutUsModel(title: "Social Media", subTitle: "Stay up-to-date on all of Cancer.Net's happenings by visiting the Cancer.Net Page on Facebook, following us on Twitter, subscribing to our YouTube channel, or subscribing to our monthly e-newsletter."),
  ];

  @override
  Widget build(BuildContext context) {
    return MediaQuery(
      data:  MediaQuery.of(context).copyWith(textScaleFactor: 1),
      child: Scaffold(
        backgroundColor: ConstColour.bgColor,
        appBar: AppBar(
          backgroundColor: ConstColour.appBarColor,
          title: const Text('About Us',
            style: TextStyle(
              color: ConstColour.appBarFontColor,
              fontFamily: ConstFont.primaryFontFamily,
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),
          ),
          actions: [
            IconButton(
            onPressed: (){
              setState(() {
                isBookmark = !isBookmark;
              });
            },
            icon: Icon(isBookmark == true ? Icons.bookmark : Icons.bookmark_border_outlined)),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(5),
          shrinkWrap: true,
          children: [
            ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: aboutUsList.length,
                itemBuilder: (context,index){
              return buildListTile(
                  title: '${aboutUsList[index].title}',
                  subTitle: '${aboutUsList[index].subTitle}',
                  onTap: (){}
              );
            }),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
  Widget buildListTile({String? title, String? subTitle, GestureTapCallback? onTap}){
    return Column(
      children: [
        const SizedBox(height: 8,),
        ListTile(
            onTap: onTap,
            shape: const RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(4)),),
            tileColor: ConstColour.white,
            title: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Text('$title',style:const TextStyle(
                color: ConstColour.primaryFontColor,
                fontSize: 15,
                fontWeight: FontWeight.bold,
                fontFamily: ConstFont.primaryFontFamily,
              ),
              ),
            ),
            subtitle:  Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Flexible(
                  child: Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Text('$subTitle',style:const TextStyle(
                      color: ConstColour.secondFontColor,
                      fontSize: 14,
                      fontWeight: FontWeight.normal,
                      fontFamily: ConstFont.primaryFontFamily,
                    ),
                    ),
                  ),
                ),
                Container(
                  height: 20,
                  width: 20,
                  alignment: Alignment.center,
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: ConstColour.bgIconColor,
                  ),
                  child: const Icon(Icons.arrow_forward_ios,size: 12,color: ConstColour.primaryColor),
                )
              ],
            ),
        ),
      ],
    );
  }
}


class AboutUsModel{
  String? title;
  String? subTitle;

  AboutUsModel({this.title,this.subTitle});
}