import 'package:flutter/material.dart';
import '../../core/constColor.dart';
import '../../core/constFonts.dart';
import '../../core/constRoute.dart';

class PrivacyAndPolicyPage extends StatefulWidget {
  const PrivacyAndPolicyPage({Key? key}) : super(key: key);

  @override
  State<PrivacyAndPolicyPage> createState() => _PrivacyAndPolicyPageState();
}

class _PrivacyAndPolicyPageState extends State<PrivacyAndPolicyPage> {

  bool isSwitched = false;

  @override
  Widget build(BuildContext context) {
    return MediaQuery(
        data:  MediaQuery.of(context).copyWith(textScaleFactor: 1),
    child: Scaffold(
      backgroundColor: const Color(0xFFE7E7E7),
      appBar: AppBar(
        backgroundColor: ConstColour.appBarColor,
        title: const Text('Privacy Policy and Terms of Use',
          style: TextStyle(
            color: ConstColour.appBarFontColor,
            fontFamily: ConstFont.primaryFontFamily,
            fontWeight: FontWeight.bold,
            fontSize: 19,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(10),
        shrinkWrap: true,
        children: [
          Card(
            margin: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(4)
            ),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  buildText(title: "ASCO and Cancer.Net respect your privacy. The personal information you enter in this app is never collected by or sent to ASCO."),
                  const SizedBox(height: 15,),
                  Column(
                    children: [
                      Row(
                        children: [
                          buildText(title: "For more information see "),
                          const Text("ASCO's Terms of  Use ",
                            style: TextStyle(
                              fontSize: 15,
                              fontFamily: ConstFont.primaryFontFamily,
                              fontWeight: FontWeight.w600,
                              color: ConstColour.bgIconColor,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                        ],
                      ),
                      Row(children: [
                        buildText(title: "and "),
                        const Text("Mobile App Privacy Policy",
                          style: TextStyle(
                            fontSize: 15,
                            fontFamily: ConstFont.primaryFontFamily,
                            fontWeight: FontWeight.w600,
                            color: ConstColour.bgIconColor,
                            decoration: TextDecoration.underline,
                          ),
                        ),
                        buildText(title: "."),
                      ],)
                    ],
                  )
                ],
              ),
            ),
          ),
          const SizedBox(height: 15,),
          Card(
            margin: const EdgeInsets.all(0),
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(4)
            ),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('Help Improve This App',
                        style: TextStyle(
                          fontSize: 17,
                          fontFamily: ConstFont.primaryFontFamily,
                          fontWeight: FontWeight.bold,
                          color: ConstColour.secondFontColor,
                        ),
                      ),
                      Switch(
                        onChanged: (value){
                          setState(() {
                            isSwitched = value;
                          });
                        },
                        value: isSwitched,
                        activeColor: const Color(0xFFF3BC00),
                        activeTrackColor: const Color(0xFFFCECB1),
                        inactiveThumbColor: const Color(0xFFEDEDED),
                        inactiveTrackColor: const Color(0xFFB2B2B2),
                      )
                    ],
                  ),
                  buildText(title: 'When "Help Improve This App" is turned on, ASCO receives anonymous information about how this app is being used on your device. This helps us understand how the app is used so it can be improved in the future. ASCO does not collect any information that could be used to identify you or your device.'),
                  const SizedBox(height: 15,),
                ],
              ),
            ),
          ),
        ],
      ),
    )
    );
  }

  Widget buildText({String? title}){
    return Text('$title',
      style: const TextStyle(
        fontSize: 15,
        fontFamily: ConstFont.primaryFontFamily,
        fontWeight: FontWeight.normal,
        color: ConstColour.secondFontColor,
      ),
    );
  }
}
