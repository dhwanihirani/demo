import 'package:cancer_net/core/constImage.dart';
import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import '../../core/constColor.dart';
import '../../core/constFonts.dart';
import '../../core/constRoute.dart';

class WelcomeTour extends StatefulWidget {
  const WelcomeTour({Key? key}) : super(key: key);

  @override
  State<WelcomeTour> createState() => _WelcomeTourState();
}

class _WelcomeTourState extends State<WelcomeTour> {

  final CarouselController _controller = CarouselController();
  int currentImage = 0;
  String showTitle = "The My Health Section offers a variety of tools to help you manage your or your loved one's cancer care.";

  @override
  Widget build(BuildContext context) {
    return MediaQuery(data:  MediaQuery.of(context).copyWith(textScaleFactor: 1),
        child: Scaffold(
          backgroundColor: const Color(0xFF002f63),
          appBar: AppBar(
            backgroundColor: ConstColour.appBarColor,
            title: const Text('Welcome',
              style: TextStyle(
                color: ConstColour.appBarFontColor,
                fontFamily: ConstFont.primaryFontFamily,
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
            actions: [TextButton(
                onPressed: (){
                  Navigator.of(context).pushNamedAndRemoveUntil(ConstRoute.bottomTabBarView, arguments: [4],(route) => false);
                },
                child: const Text('DONE',style: TextStyle(
                  color: ConstColour.appBarFontColor,
                  fontFamily: ConstFont.primaryFontFamily,
                  fontWeight: FontWeight.bold,
                  fontSize: 15,
                ),)
            )],
          ),
          body: Stack(
            alignment: Alignment.bottomCenter,
            children: [
              CarouselSlider(
                items: imgList
                .map((item) => Container(
                margin: const EdgeInsets.all(5.0),
                child: Image.asset(item.image!, fit: BoxFit.cover,),
                )).toList(),
                options: CarouselOptions(enlargeCenterPage: false,autoPlay: false,
                    viewportFraction: 1.0,
                    height: MediaQuery.of(context).size.height,
                    onPageChanged: (index, reason) {
                  setState(() {
                    showTitle = imgList[index].title!;
                    currentImage = index;
                  });
                    }
                ),
                carouselController: _controller,
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  height: 160,
                  padding: const EdgeInsets.only(top: 15,right: 10,left: 10,bottom: 5),
                  color: const Color(0xFFd7e7f4),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Text("$showTitle",
                        style: const TextStyle(
                          fontFamily: ConstFont.primaryFontFamily,
                          color: Color(0xFF042550),
                          fontWeight: FontWeight.w500,
                          fontSize: 15
                        ),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 0),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Flexible(
                              child: IconButton(
                                icon: const Icon(Icons.arrow_back,color: ConstColour.primaryColor),
                                onPressed: () {
                                  setState(() {
                                    _controller.previousPage();
                                  });
                                },
                              ),
                            ),
                            const SizedBox(width: 5),
                            ...Iterable.generate(imgList.length).map((index) =>
                            Flexible(
                              child: IconButton(
                                padding: const EdgeInsets.all(0),
                                  onPressed: (){
                                    setState(() {
                                      _controller.animateToPage(index);
                                      showTitle = imgList[index].title!;
                                    });
                                  },
                                  icon: Icon(currentImage == index ? Icons.circle : Icons.circle_outlined,color: ConstColour.appBarColor,size: 12)
                              ),
                            ),),
                            const SizedBox(width: 5),
                            Flexible(
                              child: IconButton(
                                icon: const Icon(Icons.arrow_forward,color: ConstColour.primaryColor),
                                onPressed: () {
                                  setState(() {
                                    _controller.nextPage();
                                  });
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          )
        )
    );
  }
}

final List<ShowImageModel> imgList = <ShowImageModel>[
  ShowImageModel(image: ConstImg.welcome1,title: "The My Health Section offers a variety of tools to help you manage your or your loved one's cancer care."),
  ShowImageModel(image: ConstImg.welcome2,title: "Log your symptoms and rate their severity. View your symptom severity over time."),
  ShowImageModel(image: ConstImg.welcome3,title: "Find or add questions to ask your health care team. Record answers with written notes or audio recordings."),
  ShowImageModel(image: ConstImg.welcome4,title: "Log your medications and set reminder notifications."),
  ShowImageModel(image: ConstImg.welcome5,title: "Add your health care providers and their contact information. Link questions, appointments, and symptoms to your providers."),
  ShowImageModel(image: ConstImg.welcome4,title: "Enter appointments and sync with your calender or share with others."),
  ShowImageModel(image: ConstImg.welcome5,title: "View, email, or print a report of information tracked within this app."),
  ShowImageModel(image: ConstImg.welcome8,title: "Find the newest articles, videos, and podcasts from Cancer.Net."),
  ShowImageModel(image: ConstImg.welcome9,title: "Find comprehensive, trusted information about all aspects of cancer care."),
  ShowImageModel(image: ConstImg.welcome10,title: "As you browse the News and Information sections, bookmark articles and resources to save them."),
  ];

class ShowImageModel{
  String? image;
  String? title;

  ShowImageModel({this.image,this.title});
}
