//helpWithThisAppPage
import 'package:flutter/material.dart';
import '../../core/constColor.dart';
import '../../core/constFonts.dart';
import '../../core/constRoute.dart';

class HelpWithThisAppPage extends StatefulWidget {
  const HelpWithThisAppPage({Key? key}) : super(key: key);

  @override
  State<HelpWithThisAppPage> createState() => _HelpWithThisAppPageState();
}

class _HelpWithThisAppPageState extends State<HelpWithThisAppPage> {
  @override
  Widget build(BuildContext context) {
    return MediaQuery(
        data:  MediaQuery.of(context).copyWith(textScaleFactor: 1),
    child: Scaffold(
      backgroundColor: ConstColour.bgColor,
      appBar: AppBar(
        backgroundColor: ConstColour.appBarColor,
        title: const Text('Help With This App',
          style: TextStyle(
            color: ConstColour.appBarFontColor,
            fontFamily: ConstFont.primaryFontFamily,
            fontWeight: FontWeight.bold,
            fontSize: 19,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(10),
        shrinkWrap: true,
        children: [
          ListView.builder(
              shrinkWrap: true,
              itemCount: showDetailsList.length,
              physics: const NeverScrollableScrollPhysics(),
              itemBuilder:(context, index){
                return Column(
                  children: [
                    buildTitle(title: "${showDetailsList[index].title}",icon: showDetailsList[index].icon),
                    Card(
                      margin: const EdgeInsets.all(0),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(10),
                        child: buildText(title: "${showDetailsList[index].des}"),
                      ),
                    ),
                    const SizedBox(height: 15),
                  ],
                );
              }
          ),
        ],
      ),
      )
    );
  }

  Widget buildTitle({String? title,IconData? icon}){
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4),
        color: const Color(0xFF002657),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 5),
            child: Icon(icon, size: 30, color: ConstColour.appBarFontColor),
          ),
          Text('$title',
            style:const TextStyle(
              fontSize: 20,
              fontFamily: ConstFont.primaryFontFamily,
              fontWeight: FontWeight.w500,
              color: ConstColour.appBarFontColor,
            ),
          ),
          const SizedBox(
            width: 5,
          ),
        ],
      ),
    );
  }

  Widget buildText({String? title}){
    return Text('$title',
      style: const TextStyle(
        fontSize: 13,
        fontFamily: ConstFont.primaryFontFamily,
        fontWeight: FontWeight.normal,
        color: ConstColour.secondFontColor,
      ),
    );
  }

  final List<ShowDetails> showDetailsList  = <ShowDetails>[
    ShowDetails(icon: Icons.monitor_heart_outlined,title: "My Health",
    des: 'The My Health dashboard gives you easy access to track your symptoms, questions for your health care team, medications, provider information, and appointments. It also allows you to share your tracked data with family, caregivers, and providers using the "My Health Report" function.\n\nUse the Quick Add buttons at the top of the dashboard to track a new symptom, record a new question to ask your health care team, or log an instance of taking a tracked medication (this will only appear if you have medications listed).\n\nIf you add upcoming appointments or set a reminder for a medication, your next appointment and medication reminders will also appear at the top of the dashboard for easy reference.\n\nTap on the blue and yellow arrows throughout the My Health dashboard to see additional details and track a new item (symptoms, questions, medications, etc.) in each section. Recently tracked information will appear on the main dashboard.\n\nThe information tracked within My Health can be linked across sections for easy reference For example, if you have a question about a new medication, you can link the medication and question, and assign your question to a specific provider.\n\nYou can protect the personal information you\'ve entered from unauthorized access by setting the optional passcode lock located in the upper right corner of the My Health screen.'
    ),
    ShowDetails(icon: Icons.pregnant_woman_outlined,title: "Symptoms",
    des: "Track the severity, date, and time of your symptoms and side effects. Choose from a list of common symptoms or add your own. View severity of individual symptoms over time in an easy-to-read graph. Add a reminder to track your symptoms on a daily or weekly basis."
    ),
    ShowDetails(icon: Icons.library_books, title: "Questions",
    des: "Choose from suggested questions, or jot down your own to ask your health care team at your next appointment. Record their answers via written notes or audio recording using your device's microphone for later reference. Questions can be linked to providers, symptoms, or medications."
    ),
    ShowDetails(icon: Icons.animation_outlined, title: "Medications",
    des: "Log the dosage, frequency, and prescribing doctor for your medications. Take photos of labels and bottles to easily remember important information and set reminders to take medications either daily or at specific dates and times. Medications can be linked to questions and symptoms."
    ),
    ShowDetails(icon: Icons.groups_outlined, title: "Providers",
    des: "Add your health care providers and their contact information for easy access. Assign questions, symptoms, and appointments to specific providers. Import from and save to your device's contacts."
    ),
    ShowDetails(icon: Icons.calendar_month_outlined, title: "Appointments",
    des: "Enter appointments with your providers, sync with your device calendar, and share appointment details with others. View upcoming appointments and appointment history."
    ),
    ShowDetails(icon: Icons.my_library_books_outlined, title: "My Health Report",
    des: "View, email, or print a report of all your health information within a given date range. Customize and save multiple report settings and set reminders to run and share saved reports on a regular basis."
    ),
    ShowDetails(icon: Icons.newspaper_outlined, title: "News",
    des: "See Cancer.Net articles, videos, podcasts, and announcements. Stay informed with notifications about new content. Use the icon in the upper right corner to manage your notification settings and choose which notifications display.\n\nThis content will automatically update when an internet I connection is available."
    ),
    ShowDetails(icon: Icons.menu_book_outlined, title: "Information",
    des: "Comprehensive guides on 125 types of cancer, along with general information about treating cancer, managing side effects, managing the cost of care, and living with cancer.\n\nThe information in this section is taken from the Cancer.Net website (www.cancer.net). An internet connection is required to download content the first time you view it, and this may take a few seconds. Once content is downloaded it is stored on your device so you can view it at any time."
    ),
    ShowDetails(icon: Icons.search, title: "Search",
    des: "Search within the News and information sections of the app by using the magnifying glass icon in the upper right corner. if you have tracked questions to ask your health care team, you have tracked question to ask your health care team. you can also search within the Questions section of Health."
    ),

  ];
}

class ShowDetails {
  IconData? icon;
  String? title;
  String? des;

  ShowDetails({this.icon,this.des,this.title});
}
