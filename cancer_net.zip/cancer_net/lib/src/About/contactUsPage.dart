import 'package:flutter/material.dart';
import '../../core/constColor.dart';
import '../../core/constFonts.dart';
import '../../core/constRoute.dart';

class ContactUsPage extends StatefulWidget {
  const ContactUsPage({Key? key}) : super(key: key);

  @override
  State<ContactUsPage> createState() => _ContactUsPageState();
}

class _ContactUsPageState extends State<ContactUsPage> {
  @override
  Widget build(BuildContext context) {
    return MediaQuery(
        data:  MediaQuery.of(context).copyWith(textScaleFactor: 1),
    child: Scaffold(
      backgroundColor: const Color(0xFFE7E7E7),
      appBar: AppBar(
        backgroundColor: ConstColour.appBarColor,
        title: const Text('Contact Us',
          style: TextStyle(
            color: ConstColour.appBarFontColor,
            fontFamily: ConstFont.primaryFontFamily,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(10),
        shrinkWrap: true,
        children: [
          buildTitle(title: "Call Toll-Free"),
          Material(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(4),
            ),
            elevation: 1,
            child: Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: ConstColour.white,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.wifi_calling_3,color: Color(0xFF315287),size: 100),
                  Column(
                    children: const [
                      Text('Call our toll-free patient information\n line:',
                        style: TextStyle(
                          fontSize: 13,
                          fontFamily: ConstFont.primaryFontFamily,
                          fontWeight: FontWeight.normal,
                          color: ConstColour.secondFontColor,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      Text('888-651-3038',
                        style: TextStyle(
                          fontSize: 15,
                          fontFamily: ConstFont.primaryFontFamily,
                          fontWeight: FontWeight.normal,
                          color: ConstColour.primaryFontColor,
                        ),
                      ),
                    ],
                  )
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          buildTitle(title: "Email"),
          buildDetails(icon: Icons.email_outlined,details: "contactus@cancer.net"),
          const SizedBox(height: 10),
          buildTitle(title: "Address Book"),
          buildDetails(icon: Icons.menu_book,details: "Add to Address Book"),
        ],
      ),
    )
    );
  }

  Widget buildTitle({String? title}){
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4),
        color: const Color(0xFF002657),
      ),
      child:  Text('$title',
        style:const TextStyle(
          fontSize: 20,
          fontFamily: ConstFont.primaryFontFamily,
          fontWeight: FontWeight.w500,
          color: ConstColour.appBarFontColor,
        ),
      ),
    );
  }

  Widget buildDetails({ IconData? icon, String? details}){
    return Material(
      elevation: 1,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(4),
      ),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(4),
          color: ConstColour.white,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Icon(icon,color:const Color(0xFF315287),size:100),
            Text('$details',
              style: const TextStyle(
                fontSize: 15,
                fontFamily: ConstFont.primaryFontFamily,
                fontWeight: FontWeight.normal,
                color: ConstColour.primaryFontColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
